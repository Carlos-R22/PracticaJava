# Trabajo Práctico Base de Datos 👨‍💻

Un trabajo práctico para Base de Datos I.

## En este trabajo práctico se va a hacer:
* Un modelo DER(diagrama entidad-relación).
* Un modelo MR(modelo relacional).
* Un modelo físico con un script de creación de estructuras e inserción de datos en MySQL (DML y DDL).
